
# EPHI Certificate Issuing & QR Verification Portal

A starter web application for an organization-wide certificate workflow:
- Admin login
- Issue certificates with unique certificate numbers
- Generate downloadable PDF certificates containing QR verification codes
- Public verification page
- Search records and revoke certificates
- SQLite database

## Important institutional-use notice

This is a **starter implementation**, not an officially approved Ethiopian Public Health Institute system. Do not publish it under EPHI's name, logo, domain, or issue official certificates until EPHI has authorized the project, branding, certificate template, signatories, and data handling. The current certificate layout is a generic placeholder.

Before production deployment, have the organization's IT/security team:
- Deploy behind HTTPS on an approved server/domain.
- Set strong `SECRET_KEY`, `ADMIN_USERNAME`, and `ADMIN_PASSWORD` environment variables.
- Add named staff accounts, role-based permissions, audit logs, password reset and MFA.
- Add CSRF protection, rate limiting, backups, monitoring, and retention/privacy controls.
- Confirm certificate numbering, revocation, expiry, and verification policies.
- Replace the external QR image service in the admin detail page with locally generated QR images if required by security policy.
- Review applicable Ethiopian data protection, public-sector IT, and institutional policies.

## Run locally

Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

Set environment variables before starting. Example (macOS/Linux):

```bash
export SECRET_KEY="$(python -c 'import secrets; print(secrets.token_urlsafe(48))')"
export ADMIN_USERNAME="ephi-admin"
export ADMIN_PASSWORD="use-a-long-unique-password"
python app.py
```

Windows PowerShell:

```powershell
$env:SECRET_KEY = "replace-with-a-long-random-secret"
$env:ADMIN_USERNAME = "ephi-admin"
$env:ADMIN_PASSWORD = "replace-with-a-long-unique-password"
python app.py
```

Open `http://127.0.0.1:5000`. Sign in with the environment credentials, issue a test certificate, download its PDF, and scan the QR code. The QR verification URL must be publicly reachable for off-device scanning; local `127.0.0.1` links only work on the same computer.

The first admin account is created when the database is initialized if `ADMIN_PASSWORD` is set. Keep the database file private and back it up securely.

## Project structure

- `app.py` — Flask application and SQLite data model
- `templates/` — public, admin, issue and verification pages
- `static/style.css` — responsive styling
- `requirements.txt` — Python dependencies

## Production note

The starter has a single administrator account configured through environment variables. It is not a substitute for an institution's approved identity management system or security review.


## Render test deployment

For a **test/demo deployment only**, upload this project to a GitHub repository, connect that repository to Render, and create a Web Service with:
- Build command: `pip install -r requirements.txt`
- Start command: `gunicorn app:app`
- Environment variables: `SECRET_KEY` (long random secret), `ADMIN_USERNAME`, and `ADMIN_PASSWORD`

Important: this starter currently stores certificates in SQLite on the app's local filesystem. Render Free web services have ephemeral filesystems, so certificate records can disappear after a restart, spin-down, or redeploy. Do not issue real institutional certificates on this free setup. Before real use, migrate to a persistent database/storage arrangement and complete an institutional security review.
